const getLoginPage = (req, res) => {
  res.render("login");
};

module.exports = { getLoginPage };
